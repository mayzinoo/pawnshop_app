// JavaScript Document
var site_url;


site_url="http://localhost/power/";
// site_url="http://ilbsm.itcurrent.com/index.php/";
/*Make Delete*/
///....................


function makedelete(id,table)
{    

    if(confirm("Are you sure you want to delete this item ?"))
    {
        window.location=site_url+"Admin/delete/"+table+"/"+id;                    
    }    
}

// JavaScript Document
var site_url;


site_url="http://localhost/power/";
// site_url="http://ilbsm.itcurrent.com/index.php/";
/*Make Delete*/
///....................

function makedelete(id,table)
{    

    if(confirm("Are you sure you want to delete this item ?"))
    {
        window.location=site_url+"Admin/delete/"+table+"/"+id;                    
    }    
}
function searchsingle(table)
{		
	
	$("#content").html("<tr><td align='center' colspan='18'><img src='images/loading.gif'/></td></tr>");

	var data=$("#"+table).serialize();
	$.ajax({
			type: "POST",
			url : site_url+"Main/searchsingle/"+table,
			data : data,
			success : function(e)
			{
			 $("#content").html(e);	
			}
		});
}
function collateralcloneform(arg)
{
		arg.preventDefault();
		 var cloneCount = 1;   
		 var clone=$( "div.collateralclone:last-child" ).clone().appendTo( "#collateral" );
		 clone.find("option:selected").prop("selected", false)
}
function removerlgn(event)
{
    var target = $(event.target);
    var cl=$(".collateralclone").length;
    if(cl==1)
    {
    alert("You can not remove");
    }
    else{
    target.parent().parent().remove();
    }
}